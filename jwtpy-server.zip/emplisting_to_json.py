# -*- coding: utf-8 -*-
"""
Created on Tue Jun 10 11:01:37 2025

@author: momnwz2
"""

import os
import json
import sys
import pandas as pd
from datetime import datetime
from pathlib import Path

def clean_value(value):
    """
    Clean and convert value to string format
    """
    if pd.isna(value) or value is None:
        return ""
    
    # Handle numeric values
    if isinstance(value, (int, float)):
        if float(value).is_integer():
            return str(int(value))
        return str(value)
    
    # Handle string values
    return str(value).strip()

def generate_batch_id(uen):
    """
    Generate a unique batch ID based on UEN and timestamp
    """
    timestamp = datetime.now().strftime('%Y%m%d%H%M%S')
    return f"{uen}_{timestamp}"

def excel_to_oed_json(excel_file_path, requestor_email, requestor_name):
    """
    Convert Excel data to OED JSON format
    """
    try:
        # Check if file exists
        if not os.path.exists(excel_file_path):
            raise FileNotFoundError(f"Excel file not found: {excel_file_path}")

        # Get UEN from filename
        filename = os.path.basename(excel_file_path)
        uen = os.path.splitext(filename)[0]
        
        # Generate batch ID
        batch_id = generate_batch_id(uen)

        # First, verify the Excel file structure
        xl = pd.ExcelFile(excel_file_path)
        if 'EmployeeListing' not in xl.sheet_names:
            raise ValueError("Excel file does not contain 'EmployeeListing' sheet")

        # Read the data portion of the sheet starting from row 7
        data_df = pd.read_excel(
            excel_file_path,
            sheet_name='EmployeeListing',
            skiprows=6,
            usecols="B:AG",
            header=None
        )

        print(f"Read {len(data_df)} rows of data")

        # Define the field mappings (0-based column index to JSON field name)
        field_mappings = {
            0: "fullName",              # Column B
            1: "resStatusPassType",     # Column C
            2: "nric",                  # Column D
            3: "dateJoined",           # Column E
            4: "highestEducation",     # Column F
            5: "pwJobTitle",           # Column G
            6: "mainJobTitle",         # Column H
            7: "mainJobDuties",        # Column I
            13: "occupationGroup",      # Column O
            14: "typeOfEmployee",       # Column P
            15: "jobType",             # Column Q
            16: "department",           # Column R
            17: "standard_hr_wrk",      # Column S
            18: "actual_hr_wrk",        # Column T
            21: "totalWorkingDaysofMonth",  # Column W
            22: "actualWorkingDaysofMonth", # Column X
            23: "paymentMode",          # Column Y
            24: "basicWage",            # Column Z
            25: "grossWage",            # Column AA
            26: "annualLeaves",         # Column AB
            27: "premiseType",          # Column AC
            28: "postalCode",           # Column AD
            29: "streetName",           # Column AE
            30: "dateLeft",             # Column AF
            31: "modeOfLeaving"         # Column AG
        }

        # Calculate batch information
        total_records = len(data_df)
        batch_size = 2000
        total_batches = (total_records + batch_size - 1) // batch_size

        # Process data in batches
        all_batches = []
        for current_batch in range(1, total_batches + 1):
            start_idx = (current_batch - 1) * batch_size
            end_idx = min(current_batch * batch_size, total_records)
            
            # Create the batch JSON structure
            batch_json = {
                "dateSent": datetime.now().strftime("%Y%m%d"),
                "uen": uen,
                "requestorEmail": requestor_email,
                "requestorName": requestor_name,
                "batchID": batch_id,
                "currentBatch": current_batch,
                "totalBatches": total_batches,
                "oedData": []
            }

            # Process rows for this batch
            for idx in range(start_idx, end_idx):
                try:
                    row = data_df.iloc[idx]
                    employee_data = {}
                    
                    # Process each field according to the mapping
                    for col_idx, field_name in field_mappings.items():
                        try:
                            value = clean_value(row.iloc[col_idx])
                            if value:  # Only add non-empty values
                                employee_data[field_name] = value
                        except Exception as field_error:
                            print(f"Warning: Error processing field {field_name} in row {idx + 7}: {str(field_error)}")
                            continue

                    # Set default values for HR-related fields
                    # employee_data["isEmployeeHRRole"] = "No"
                    
                    if employee_data:  # Only add if there's actual data
                        batch_json["oedData"].append(employee_data)
                        print(f"Successfully processed row {idx + 7}")
                    
                except Exception as e:
                    print(f"Warning: Error processing row {idx + 7}: {str(e)}")
                    continue

            all_batches.append(batch_json)

        if not all_batches or not all_batches[0]["oedData"]:
            raise ValueError("No valid data rows found in Excel file")

        return all_batches

    except Exception as e:
        print(f"Error processing Excel file: {str(e)}")
        raise

# def process_excel_to_json(excel_file, requestor_email, requestor_name, output_dir="."):
#     """
#     Process single Excel file to JSON
#     """
#     try:
#         # Ensure output directory exists
#         os.makedirs(output_dir, exist_ok=True)

#         # Convert Excel to JSON batches
#         json_batches = excel_to_oed_json(
#             excel_file,
#             requestor_email,
#             requestor_name
#         )

#         # Create output filename based on input filename
#         base_filename = os.path.splitext(os.path.basename(excel_file))[0]
        
#         output_files = []
#         for i, batch in enumerate(json_batches, 1):
#             output_file = os.path.join(output_dir, f"{base_filename}_batch_{i}.json")
#             with open(output_file, 'w', encoding='utf-8') as f:
#                 # Convert to string first
#                 json_str = json.dumps(batch, indent=2, ensure_ascii=False)
#                 # Remove commas between array elements
#                 json_str = json_str.replace("},\n", "}\n")
#                 f.write(json_str)
#             output_files.append(output_file)
#             print(f"Batch {i}/{len(json_batches)} saved to {output_file} ({len(batch['oedData'])} records)")

#         return output_files

#     except Exception as e:
#         print(f"Error processing file {excel_file}: {str(e)}")
#         return []
import hashlib

def calculate_sha256(json_str):
    """
    Calculate SHA256 hash of a string
    """
    return hashlib.sha256(json_str.encode('utf-8')).hexdigest()

def process_excel_to_json(excel_file, requestor_email, requestor_name, output_dir="."):
    """
    Process single Excel file to JSON
    """
    try:
        # Ensure output directory exists
        os.makedirs(output_dir, exist_ok=True)

        # Convert Excel to JSON batches
        json_batches = excel_to_oed_json(
            excel_file,
            requestor_email,
            requestor_name
        )

        # Create output filename based on input filename
        base_filename = os.path.splitext(os.path.basename(excel_file))[0]
        
        output_files = []
        for i, batch in enumerate(json_batches, 1):
            # Convert batch to JSON string
            json_str = json.dumps(batch, ensure_ascii=False, separators=(',', ':'))
            
            # Calculate SHA256 hash
            sha256_hash = calculate_sha256(json_str)
            
            # Add hash to the batch
            batch['sha256Hash'] = sha256_hash
            
            # Convert to final JSON string with hash
            final_json_str = json.dumps(batch, ensure_ascii=False, separators=(',', ':'))
            
            output_file = os.path.join(output_dir, f"{base_filename}_batch_{i}.json")
            with open(output_file, 'w', encoding='utf-8') as f:
                f.write(final_json_str)
            
            output_files.append(output_file)
            print(f"Batch {i}/{len(json_batches)} saved to {output_file} ({len(batch['oedData'])} records)")
            #print(f"SHA256 Hash: {sha256_hash}")

        return output_files

    except Exception as e:
        print(f"Error processing file {excel_file}: {str(e)}")
        return []

def process_directory(input_path, requestor_email, requestor_name, output_dir="."):
    """
    Process all Excel files in a directory
    """
    try:
        # Convert to Path object
        input_path = Path(input_path)
        
        # If input is a file, process just that file
        if input_path.is_file():
            if input_path.suffix.lower() in ['.xlsx', '.xls']:
                return process_excel_to_json(str(input_path), requestor_email, requestor_name, output_dir)
            else:
                print(f"Skipping non-Excel file: {input_path}")
                return []

        # If input is a directory, process all Excel files
        elif input_path.is_dir():
            all_output_files = []
            excel_files = list(input_path.glob("*.xlsx")) + list(input_path.glob("*.xls"))
            
            if not excel_files:
                print(f"No Excel files found in directory: {input_path}")
                return []

            print(f"\nFound {len(excel_files)} Excel files to process")
            
            for i, excel_file in enumerate(excel_files, 1):
                print(f"\nProcessing file {i} of {len(excel_files)}: {excel_file.name}")
                output_files = process_excel_to_json(
                    str(excel_file),
                    requestor_email,
                    requestor_name,
                    output_dir
                )
                all_output_files.extend(output_files)
            
            return all_output_files
        
        else:
            raise FileNotFoundError(f"Path not found: {input_path}")

    except Exception as e:
        print(f"Error processing directory: {str(e)}")
        return []

def main():
    """
    Main function to run the script
    """
    try:
        # Get input parameters
        input_path = input("Enter the path to Excel file or directory: ").strip()
        requestor_email = input("Enter requestor email: ").strip()
        requestor_name = input("Enter requestor name: ").strip()
        output_dir = input("Enter output directory (press Enter for current directory): ").strip()
        
        if not output_dir:
            output_dir = "output"  # Default output directory

        # Process the files
        output_files = process_directory(input_path, requestor_email, requestor_name, output_dir)

        if output_files:
            print(f"\nSuccessfully processed {len(output_files)} JSON files:")
            for file in output_files:
                print(f"- {os.path.basename(file)}")
        else:
            print("\nNo files were processed successfully.")

    except Exception as e:
        print(f"\nError: {str(e)}")
        return 1

    return 0


#Sebastian added code
def get_first_batch_payload(file_path, email, name):
    """
    Returns the first JSON batch directly (instead of writing to file)
    """
    json_batches = excel_to_oed_json(file_path, email, name)
    return json_batches[0]  # returns only first batch


if __name__ == "__main__":
    sys.exit(main())
    
