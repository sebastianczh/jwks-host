import sys  # Make sure this is at the top of your file
import json
import hashlib
import uuid
import time
import os
import requests
from jwcrypto import jwk, jwt
from emplisting_to_json import get_first_batch_payload


# =============================================
# 1️⃣ Generate JSON Payload from Excel
# =============================================
#
# +++++++++++++++Can be edited+++++++++++++++
excel_file_path = r"C:\Users\Sebastian\OneDrive\Desktop\jwt-server\Emplisting\180016248K.xlsx"
requestor_email = "sebastianczh@outlook.sg" #our MOM email
requestor_name = "SebastianCZH_test" #LANID?
# +++++++++++++++++++++++++++++++++++++++++++
data_payload = get_first_batch_payload(excel_file_path, requestor_email, requestor_name)
uen = data_payload["uen"]
print(f"✅ Loaded UEN: {uen}, Records: {len(data_payload['oedData'])}")

# =============================================
# 2️⃣ Save Payload JSON next to Excel file
# =============================================
excel_dir = os.path.dirname(excel_file_path)
payload_filename = f"{uen}_payload.json"
payload_output_path = os.path.join(excel_dir, payload_filename)

with open(payload_output_path, "w", encoding="utf-8") as f:
    json.dump(data_payload, f, ensure_ascii=False, separators=(',', ':'))

print(f"✅ Payload saved to: {payload_output_path}")

# =============================================
# 🔐 Prompt before proceeding with POST
# =============================================
print("\n📄 Review the generated payload before sending:")
print(f"   → File: {payload_output_path}")
print(f"   → Records: {len(data_payload['oedData'])}")
print(f"   → UEN: {uen}")

proceed = input("\n⚠️ Do you want to proceed with sending the POST request? (yes/no): ").strip().lower()
if proceed != "yes":
    print("❌ POST request aborted by user.")
    sys.exit(0)


# =============================================
# 3️⃣ Hash Payload with SHA-256
# =============================================
compact = json.dumps(data_payload, separators=(',', ':'))
hashed_payload = hashlib.sha256(compact.encode()).hexdigest()
print(f"\n✅ Final hash to use in JWT 'data' claim:\n{hashed_payload}\n")

# =============================================
# 4️⃣ Generate JWT Claims
# =============================================
timestamp_now = int(time.time())
timestamp_exp = timestamp_now + 180 #in seconds 900sec = 15mins

claims = {
    "data": hashed_payload,
    "jti": str(uuid.uuid4()),
    "iat": timestamp_now,
    "exp": timestamp_exp,
    "iss": "c66446db-9221-4b84-9632-2abd5781a250",# Application Client ID
    "sub": "POST", #POST
    "aud": "https://sandbox.api.gov.sg/mom/oed/jwt/lssp/ez/laboursurvey/prc/v2/Submission" #Sending to who... or which endpoint?
}

# =============================================
# 5️⃣ Load Signing Key (Private JWK)
# =============================================
with open("private-jwk.json") as f:
    key = jwk.JWK.from_json(f.read())

# =============================================
# 6️⃣ Create and Sign JWT Token
# =============================================
header = {
    "alg": "ES256",
    "kid": key.get("kid"),
    "typ": "JWT"
}

token = jwt.JWT(header=header, claims=claims)
token.make_signed_token(key)
jwt_token = token.serialize()
print(f"\n✅ JWT Token:\n{jwt_token}\n")

# =============================================
# 7️⃣ POST JWT + Payload to APEX Endpoint
# =============================================
url = "https://sandbox.api.gov.sg/mom/oed/jwt/lssp/ez/laboursurvey/prc/v2/Submission"
api_key = "c66446db-9221-4b84-9632-2abd5781a250"  # Replace securely in production

headers = {
    "x-apex-jwt": jwt_token,
    "x-api-key": api_key,
    "Content-Type": "application/json"
}

# ❗ Use compact string for body to match SHA256
response = requests.post(url, headers=headers, data=compact.encode("utf-8"))

print(f"\n✅ API Response Status: {response.status_code}")
print("✅ Response Body:\n", response.text)

# Save response to same folder as payload
response_path = os.path.join(excel_dir, f"{uen}_response.json")
with open(response_path, "w", encoding="utf-8") as f:
    f.write(response.text)

print(f"✅ Response saved to: {response_path}")
